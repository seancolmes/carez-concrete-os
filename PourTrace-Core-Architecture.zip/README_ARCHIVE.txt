PourTrace Core Architecture extraction

This archive contains source and configuration needed to analyze the application shell, route redirects, design tokens, theme state, UI button primitive, and dependency versions. PRIMARY_TREE.txt is a source tree and active page/API inventory. No environment files or credentials are included. Tailwind CSS 4 uses app/globals.css and postcss.config.mjs; there is no tailwind.config.ts or tailwind.config.js. docs/ARCHITECTURE.md is a target architecture document; verify current implementation against source.
