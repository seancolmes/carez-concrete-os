'use client';

import {useCallback,useEffect,useMemo,useRef,useState} from 'react';
import {useRouter} from 'next/navigation';
import {
  Check,ChevronLeft,ChevronRight,Crosshair,Hand,Magnet,Maximize,Minus,MousePointer2,MoveHorizontal,
  PanelRightClose,PanelRightOpen,Pencil,Plus,Redo2,RotateCcw,Ruler,Scissors,Trash2,Undo2,X
} from 'lucide-react';
import {
  createDrawingMeasurement,deleteDrawingMeasurement,deleteTakeoffScaleRegion,initializeTakeoffSheets,
  saveTakeoffScaleRegion,updateDrawingMeasurementGeometry
} from '@/app/takeoff/[setId]/actions';
import {GeometryCommandHistory,type CommandHistorySnapshot,type GeometryCommandKind} from '@/lib/takeoff/commandHistory';
import {measureDrawingGeometry,roundMeasurement,type DrawingGeometry,type DrawingMeasurement,type NormalizedPoint} from '@/lib/takeoff/geometry';
import {linearFootprint,parseRenderConfig,resolveDisplayStyle} from '@/lib/takeoff/physicalGeometry';
import {formatArchitecturalLength,formatTakeoffMeasurement} from '@/lib/takeoff/lengthFormat';
import {sheetDisplayLabel} from '@/lib/takeoff/sheetMetadata';
import {boundsFromPoints,calibrationFromDetectedScale,calibrationFromManual,findScaleRegionForPoint,type ScaleCalibration,type ScaleCandidate,type TakeoffScaleRegion} from '@/lib/takeoff/scaleRegions';
import {TakeoffMeasurementHoverOverlay} from './TakeoffMeasurementHoverOverlay';
import {TakeoffQuantityDock} from './TakeoffQuantityDock';
import {TakeoffScaleOverlay} from './TakeoffScaleOverlay';
import {TakeoffScalePanel} from './TakeoffScalePanel';
import {TakeoffVertexEditor} from './TakeoffVertexEditor';
import {usePdfScaleDetection} from './usePdfScaleDetection';
import styles from './TakeoffDrawingWorkspace.module.css';

type Tool='select'|'pan'|'calibrate'|'scaleRegion'|'draw'|'cutout'|'edit';
type Props={
  takeoffSet:any;
  estimate:any;
  pdfUrl:string;
  sourceTitle:string;
  initialSheets:any[];
  scaleRegions:any[];
  initialMeasurements:any[];
  measurementSummaries:any[];
  assemblies:any[];
  versions:any[];
  variables:any[];
  sections:any[];
  riskClasses:any[];
  methodProfiles:any[];
  locked:boolean;
  mobileReview?:boolean;
  drawingViewHidden?:boolean;
  conditionMeasurementIds?:string[];
  conditionSelectedMeasurementId?:string|null;
  onConditionMeasurementSelect?:(measurementId:string|null)=>void;
  conditionPresentation?:{hiddenMeasurementIds:string[];colors:Record<string,string>};
};
type RenderBox={width:number;height:number;pdfWidth:number;pdfHeight:number};
type ResolvedPoint={point:NormalizedPoint;snapped:boolean};
type ZoomAnchor={x:number;y:number;clientX:number;clientY:number};

const palette=['#426F93','#009966','#8A610B','#B84558','#6F9FC6','#525C57','#E06B74','#6DBB77'];
const MIN_ZOOM=.2;
const MAX_ZOOM=20;
const MAX_RENDER_PIXELS=28_000_000;
const MAX_CANVAS_DIMENSION=16_000;
const SNAP_PX=12;
const qty=(n:any,digits=2)=>Number(n||0).toLocaleString('en-US',{maximumFractionDigits:digits});
const money=(n:any)=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(Number(n||0));

function hashColor(value:string){let hash=0;for(let i=0;i<value.length;i++)hash=((hash<<5)-hash+value.charCodeAt(i))|0;return palette[Math.abs(hash)%palette.length];}
function normalizedPoints(points:any):NormalizedPoint[]{if(!Array.isArray(points))return[];return points.filter((p:any)=>Number.isFinite(Number(p?.x))&&Number.isFinite(Number(p?.y))).map((p:any)=>({x:Number(p.x),y:Number(p.y)}));}
function drawingGeometry(raw:any):DrawingGeometry|null{
  if(!raw||!['polyline','polygon','count'].includes(raw.type))return null;
  const points=normalizedPoints(raw.points);if(!points.length)return null;
  const holes=raw.type==='polygon'&&Array.isArray(raw.holes)?raw.holes.map(normalizedPoints).filter((hole:NormalizedPoint[])=>hole.length>=3):undefined;
  return{type:raw.type,points,...(holes?.length?{holes}:{})} as DrawingGeometry;
}
function geometryPath(geometry:DrawingGeometry,width:number,height:number){const ring=(points:NormalizedPoint[])=>points.length?`M ${points.map(point=>`${point.x*width} ${point.y*height}`).join(' L ')} Z`:'';return[ring(geometry.points),...(geometry.holes||[]).map(ring)].filter(Boolean).join(' ');}
function copyGeometry(geometry:DrawingGeometry):DrawingGeometry{return{type:geometry.type,points:geometry.points.map(point=>({...point})),...(geometry.holes?.length?{holes:geometry.holes.map(hole=>hole.map(point=>({...point})))}:{})};}
function shiftGeometry(geometry:DrawingGeometry,dx:number,dy:number):DrawingGeometry{const all=[...geometry.points,...(geometry.holes||[]).flat()];const minX=Math.min(...all.map(point=>point.x)),maxX=Math.max(...all.map(point=>point.x)),minY=Math.min(...all.map(point=>point.y)),maxY=Math.max(...all.map(point=>point.y));const safeDx=Math.max(-minX,Math.min(1-maxX,dx)),safeDy=Math.max(-minY,Math.min(1-maxY,dy));const shift=(point:NormalizedPoint)=>({x:point.x+safeDx,y:point.y+safeDy});return{type:geometry.type,points:geometry.points.map(shift),...(geometry.holes?.length?{holes:geometry.holes.map(hole=>hole.map(shift))}:{})};}
function physicalFootprint(points:NormalizedPoint[],version:any,values:any,calibration:any,box:any,anchor:any='center',offset:any=0){const config=parseRenderConfig(version?.render_config);const scale=Number(calibration?.ft_per_pdf_unit||calibration?.known_distance_ft/calibration?.pdf_distance);const width=Number(values?.[config?.widthVariable||'']);if(!config||config.mode!=='linear_buffer'||!(scale>0&&width>0))return[];return linearFootprint(points,box.pdfWidth,box.pdfHeight,scale,config.widthUnit==='FT'?width*12:width,anchor,Number(offset||0));}
function isTypingTarget(target:EventTarget|null){const el=target as HTMLElement|null;return Boolean(el&&['INPUT','TEXTAREA','SELECT'].includes(el.tagName));}
function clampZoom(value:number){return Math.max(MIN_ZOOM,Math.min(MAX_ZOOM,value));}

export function TakeoffDrawingWorkspace(props:Props){
  const {takeoffSet,pdfUrl,initialSheets,scaleRegions,initialMeasurements,measurementSummaries,assemblies,versions,variables,sections,methodProfiles,locked}=props;
  const mobileReview=Boolean(props.mobileReview);
  const conditionMeasurementIdSet=useMemo(()=>new Set(props.conditionMeasurementIds||[]),[props.conditionMeasurementIds]);
  const router=useRouter();
  const openConditions=useCallback(()=>{if(!locked&&!mobileReview)window.dispatchEvent(new CustomEvent('carez:open-conditions'));},[locked,mobileReview]);
  const canvasRef=useRef<HTMLCanvasElement|null>(null);
  const viewportRef=useRef<HTMLDivElement|null>(null);
  const paperRef=useRef<HTMLDivElement|null>(null);
  const pdfRef=useRef<any>(null);
  const renderTaskRef=useRef<any>(null);
  const panRef=useRef<{x:number;y:number;left:number;top:number}|null>(null);
  const initializingRef=useRef(false);
  const zoomAnchorRef=useRef<ZoomAnchor|null>(null);
  const historyRef=useRef(new GeometryCommandHistory());
  const editOriginalRef=useRef<DrawingGeometry|null>(null);

  const [pdfReady,setPdfReady]=useState(false);
  const [pdfPageCount,setPdfPageCount]=useState(Number(takeoffSet.page_count||initialSheets.length||0));
  const [pageNumber,setPageNumber]=useState(initialSheets[0]?.page_number||1);
  const [zoom,setZoom]=useState(1);
  const [fitWidth,setFitWidth]=useState(900);
  const [renderBox,setRenderBox]=useState<RenderBox|null>(null);
  const [renderQuality,setRenderQuality]=useState(1);
  const [tool,setTool]=useState<Tool>('select');
  const [draftPoints,setDraftPoints]=useState<NormalizedPoint[]>([]);
  const [hoverPoint,setHoverPoint]=useState<NormalizedPoint|null>(null);
  const [hoverSnapped,setHoverSnapped]=useState(false);
  const [calibrationPoints,setCalibrationPoints]=useState<NormalizedPoint[]>([]);
  const [knownDistanceFt,setKnownDistanceFt]=useState('10');
  const [draftScaleRegionId,setDraftScaleRegionId]=useState<string|null>(null);
  const [scaleRegionPoints,setScaleRegionPoints]=useState<NormalizedPoint[]>([]);
  const [pendingScaleCandidate,setPendingScaleCandidate]=useState<ScaleCandidate|null>(null);
  const [pendingManualCalibration,setPendingManualCalibration]=useState<ScaleCalibration|null>(null);
  const [localSelectedMeasurementId,setLocalSelectedMeasurementId]=useState<string|null>(null);
  const selectedMeasurementId=props.onConditionMeasurementSelect?props.conditionSelectedMeasurementId??null:localSelectedMeasurementId;
  const setSelectedMeasurementId=useCallback((id:string|null)=>{if(props.onConditionMeasurementSelect)props.onConditionMeasurementSelect(id);else setLocalSelectedMeasurementId(id);},[props.onConditionMeasurementSelect]);
  const [editGeometry,setEditGeometry]=useState<DrawingGeometry|null>(null);
  const [historySnapshot,setHistorySnapshot]=useState<CommandHistorySnapshot>(()=>historyRef.current.snapshot());
  const conditionDrawRef=useRef<{name:string;roleLabel:string}|null>(null);
  const [selectedAssemblyId,setSelectedAssemblyId]=useState<string>('');
  const [conditionDrawActive,setConditionDrawActive]=useState(false);
  const [objectName,setObjectName]=useState('');
  const [riskClassCode,setRiskClassCode]=useState('');
  const [selectedMethodProfileId,setSelectedMethodProfileId]=useState<string|null>(null);
  const [variableValues,setVariableValues]=useState<Record<string,string>>({});
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState('Loading PDF plans…');
  const [panning,setPanning]=useState(false);
  const [spaceHeld,setSpaceHeld]=useState(false);
  const [snapEnabled,setSnapEnabled]=useState(true);
  const [orthoEnabled,setOrthoEnabled]=useState(false);
  const [inspectorOpen,setInspectorOpen]=useState(false);
  useEffect(()=>{
    if(mobileReview){
      setInspectorOpen(false);
      setTool('pan');
      setDraftPoints([]);
      setCalibrationPoints([]);
      setScaleRegionPoints([]);
      setEditGeometry(null);
      setConditionDrawActive(false);
      return;
    }
  },[mobileReview]);
  const [inspectorTab,setInspectorTab]=useState<'takeoffs'|'properties'>('takeoffs');

  const latestVersionByAssembly=useMemo(()=>{const map=new Map<string,any>();for(const version of versions)if(!map.has(version.assembly_id))map.set(version.assembly_id,version);return map;},[versions]);
  const assemblyMap=useMemo(()=>new Map<string,any>(assemblies.map((a:any)=>[a.id,a])),[assemblies]);
  const versionMap=useMemo(()=>new Map<string,any>(versions.map((v:any)=>[v.id,v])),[versions]);
  const selectedAssembly:any=assemblyMap.get(selectedAssemblyId);
  const selectedVersion:any=selectedAssembly?latestVersionByAssembly.get(selectedAssembly.id):null;
  const selectedVariables=useMemo(()=>selectedVersion?variables.filter((v:any)=>v.assembly_version_id===selectedVersion.id):[],[selectedVersion,variables]);
  const currentSheet=useMemo(()=>initialSheets.find((s:any)=>Number(s.page_number)===pageNumber)||null,[initialSheets,pageNumber]);
  const currentMeasurements=useMemo(()=>initialMeasurements.filter((m:any)=>m.sheet_id===currentSheet?.id),[initialMeasurements,currentSheet]);
  const currentScaleRegions=useMemo(()=>scaleRegions.filter((region:any)=>region.sheet_id===currentSheet?.id) as TakeoffScaleRegion[],[scaleRegions,currentSheet?.id]);
  const scaleRegionMap=useMemo(()=>new Map((scaleRegions as TakeoffScaleRegion[]).map(region=>[region.id,region])),[scaleRegions]);
  const currentScale=currentScaleRegions.length>0||currentSheet?.scale_status==='calibrated';
  const currentScaleLabel=currentScaleRegions.find(region=>region.is_default)?.scale_label||currentScaleRegions[0]?.scale_label||currentSheet?.calibration?.scale_label||'UNSET';
  const {candidates:scaleCandidates,status:scaleDetectionStatus}=usePdfScaleDetection(pdfRef,pdfReady,pageNumber);
  const visibleScaleCandidates=useMemo(()=>scaleCandidates.filter(candidate=>!currentScaleRegions.some(region=>region.is_default&&region.source_type==='pdf_text'&&region.scale_label===candidate.label)),[scaleCandidates,currentScaleRegions]);
  const selectedMeasurement=initialMeasurements.find((m:any)=>m.id===selectedMeasurementId)||null;
  useEffect(()=>{if(!props.onConditionMeasurementSelect||!selectedMeasurement)return;const sheet=initialSheets.find((s:any)=>s.id===selectedMeasurement.sheet_id);if(sheet&&Number(sheet.page_number)!==pageNumber)setPageNumber(Number(sheet.page_number));},[selectedMeasurementId,selectedMeasurement?.sheet_id]);
  const selectedGeometry=useMemo(()=>selectedMeasurement?drawingGeometry(selectedMeasurement.geometry):null,[selectedMeasurement]);
  const selectedScaleRegion=selectedMeasurement?scaleRegionMap.get(selectedMeasurement.scale_region_id):null;
  const selectedCalibration=selectedScaleRegion?.calibration||currentSheet?.calibration||null;
  const draftScaleRegion=draftScaleRegionId?scaleRegionMap.get(draftScaleRegionId):null;
  const draftCalibration=draftScaleRegion?.calibration||null;
  const selectedCutoutCount=selectedGeometry?.holes?.length||0;

  const summaryMap=useMemo(()=>{
    const map=new Map<string,{mh:number;cost:number;missing:number;inputHolds:number;priceHolds:number}>();
    for(const row of measurementSummaries){
      const prior=map.get(row.measurement_id)||{mh:0,cost:0,missing:0,inputHolds:0,priceHolds:0};
      prior.mh+=Number(row.estimated_man_hours||0);prior.cost+=Number(row.direct_cost||0);
      if(row.pricing_status==='missing_input'){prior.missing+=1;prior.inputHolds+=1;}
      else if(['missing_price','missing_labor_rate'].includes(row.pricing_status)){prior.missing+=1;prior.priceHolds+=1;}
      map.set(row.measurement_id,prior);
    }
    return map;
  },[measurementSummaries]);
  const selectedSummary=selectedMeasurement?summaryMap.get(selectedMeasurement.id):null;

  useEffect(()=>{
    const startConditionTakeoff=(event:Event)=>{
      if(locked)return;
      const detail=(event as CustomEvent<{assemblyVersionId?:string;name?:string;roleLabel?:string}>).detail||{};
      const version:any=versionMap.get(String(detail.assemblyVersionId||''));
      if(!version){setMessage('The Concrete Condition takeoff recipe is unavailable. Refresh and try again.');return;}
      const request={
        name:String(detail.name||'Concrete Condition'),
        roleLabel:String(detail.roleLabel||'Condition takeoff'),
      };
      conditionDrawRef.current=request;
      setConditionDrawActive(true);
      if(version.assembly_id===selectedAssemblyId){
        setSelectedMeasurementId(null);
        setEditGeometry(null);
        editOriginalRef.current=null;
        setObjectName(request.name);
        setDraftPoints([]);
        setDraftScaleRegionId(null);
        setHoverPoint(null);
        setTool('draw');
        setInspectorOpen(false);
        setInspectorTab('properties');
        setMessage(`Draw ${request.roleLabel} on the plan. Double-click to finish LF; click the first point to close SF.`);
        conditionDrawRef.current=null;
      }else{
        setSelectedAssemblyId(version.assembly_id);
      }
    };
    window.addEventListener('carez:start-condition-takeoff',startConditionTakeoff as EventListener);
    return()=>window.removeEventListener('carez:start-condition-takeoff',startConditionTakeoff as EventListener);
  },[locked,selectedAssemblyId,versionMap]);

  useEffect(()=>{
    if(selectedMeasurementId&&!selectedMeasurement){setSelectedMeasurementId(null);setEditGeometry(null);editOriginalRef.current=null;if(tool==='edit'||tool==='cutout')setTool('select');}
  },[selectedMeasurementId,selectedMeasurement,tool]);

  useEffect(()=>{
    if(!selectedVersion)return;
    const next:Record<string,string>={};
    for(const variable of selectedVariables){if(variable.variable_key==='perimeter_lf'&&selectedAssembly?.primary_measurement==='SF')continue;next[variable.variable_key]=variable.default_value===null||variable.default_value===undefined?'':String(variable.default_value);}
    const profile=methodProfiles.find((entry:any)=>entry.assembly_version_id===selectedVersion.id&&entry.status==='verified')||null;
    if(profile){for(const [key,value] of Object.entries(profile.method_inputs||{}))next[key]=value===null||value===undefined?'':String(value);}
    const pendingConditionDraw=conditionDrawRef.current;
    setVariableValues(next);
    setSelectedMethodProfileId(profile?.id||null);
    setRiskClassCode(selectedVersion.default_risk_class_code||'');
    setObjectName(pendingConditionDraw?.name||'');
    setDraftPoints([]);
    setDraftScaleRegionId(null);
    setHoverPoint(null);
    if(pendingConditionDraw){
      setSelectedMeasurementId(null);
      setEditGeometry(null);
      editOriginalRef.current=null;
      setTool('draw');
      setInspectorOpen(false);
      setInspectorTab('properties');
      setMessage(`Draw ${pendingConditionDraw.roleLabel} on the plan. Double-click to finish LF; click the first point to close SF.`);
      conditionDrawRef.current=null;
    }
  },[selectedVersion?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(()=>{
    let cancelled=false;
    async function loadPdf(){
      try{
        setMessage('Loading PDF plans…');
        const pdfjs=await import('pdfjs-dist');
        pdfjs.GlobalWorkerOptions.workerSrc='/pdf.worker.min.mjs';
        const pdf=await pdfjs.getDocument({url:pdfUrl}).promise;
        if(cancelled){await pdf.destroy();return;}
        pdfRef.current=pdf;setPdfPageCount(pdf.numPages);setPdfReady(true);setMessage(`${pdf.numPages} sheet${pdf.numPages===1?'':'s'} loaded`);
        const sheetComplete=initialSheets.length===pdf.numPages&&initialSheets.every((s:any)=>Number(s.page_width||0)>0&&Number(s.page_height||0)>0);
        if(!sheetComplete&&!locked&&!initializingRef.current){
          initializingRef.current=true;
          const pages:{pageNumber:number;width:number;height:number}[]=[];
          for(let i=1;i<=pdf.numPages;i++){const page=await pdf.getPage(i);const viewport=page.getViewport({scale:1});pages.push({pageNumber:i,width:viewport.width,height:viewport.height});page.cleanup();}
          await initializeTakeoffSheets(takeoffSet.id,pages);setMessage('Drawing sheets prepared');router.refresh();
        }
      }catch(error:any){setMessage(error?.message||'Could not load PDF plans.');}
    }
    void loadPdf();
    return()=>{cancelled=true;renderTaskRef.current?.cancel?.();const pdf=pdfRef.current;pdfRef.current=null;if(pdf)void pdf.destroy?.();};
  },[pdfUrl]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(()=>{
    const el=viewportRef.current;if(!el)return;
    const update=()=>setFitWidth(Math.max(320,el.clientWidth-34));update();
    const observer=new ResizeObserver(update);observer.observe(el);return()=>observer.disconnect();
  },[inspectorOpen]);

  useEffect(()=>{
    if(!pdfReady||!pdfRef.current||!canvasRef.current)return;
    let cancelled=false;
    async function render(){
      try{
        renderTaskRef.current?.cancel?.();
        const page=await pdfRef.current.getPage(pageNumber);
        const base=page.getViewport({scale:1});
        const fitScale=Math.max(.05,fitWidth/base.width);
        const displayScale=fitScale*zoom;
        const displayViewport=page.getViewport({scale:displayScale});
        const desiredDpr=Math.max(1,Math.min(2,window.devicePixelRatio||1));
        const maxPixelScale=Math.sqrt(MAX_RENDER_PIXELS/(base.width*base.height));
        const maxDimensionScale=Math.min(MAX_CANVAS_DIMENSION/base.width,MAX_CANVAS_DIMENSION/base.height);
        const renderScale=Math.min(displayScale*desiredDpr,maxPixelScale,maxDimensionScale);
        const renderViewport=page.getViewport({scale:Math.max(.05,renderScale)});
        if(cancelled)return;
        const canvas=canvasRef.current!;
        canvas.style.width=`${displayViewport.width}px`;canvas.style.height=`${displayViewport.height}px`;
        setRenderBox({width:displayViewport.width,height:displayViewport.height,pdfWidth:base.width,pdfHeight:base.height});
        setRenderQuality(renderScale/displayScale);
        // Render the replacement frame offscreen so wheel zoom never clears the visible PDF bitmap.
        // The current bitmap scales with CSS and remains aligned with the SVG overlay until the sharper frame is ready.
        const staging=document.createElement('canvas');
        staging.width=Math.max(1,Math.floor(renderViewport.width));staging.height=Math.max(1,Math.floor(renderViewport.height));
        const stagingContext=staging.getContext('2d',{alpha:false});if(!stagingContext)throw new Error('Canvas is unavailable.');
        const task=page.render({canvasContext:stagingContext,viewport:renderViewport});renderTaskRef.current=task;await task.promise;
        if(cancelled)return;
        const visible=canvasRef.current;if(!visible)return;
        visible.width=staging.width;visible.height=staging.height;
        const context=visible.getContext('2d',{alpha:false});if(!context)throw new Error('Canvas is unavailable.');
        context.drawImage(staging,0,0);page.cleanup();
      }catch(error:any){if(error?.name!=='RenderingCancelledException')setMessage(error?.message||'Could not render this PDF page.');}
    }
    void render();return()=>{cancelled=true;renderTaskRef.current?.cancel?.();};
  },[pdfReady,pageNumber,zoom,fitWidth]);

  useEffect(()=>{
    const anchor=zoomAnchorRef.current;const viewport=viewportRef.current;const paper=paperRef.current;
    if(!anchor||!viewport||!paper||!renderBox)return;
    const id=requestAnimationFrame(()=>{
      const rect=paper.getBoundingClientRect();
      const targetX=rect.left+rect.width*anchor.x;const targetY=rect.top+rect.height*anchor.y;
      viewport.scrollLeft+=targetX-anchor.clientX;viewport.scrollTop+=targetY-anchor.clientY;zoomAnchorRef.current=null;
    });
    return()=>cancelAnimationFrame(id);
  },[renderBox?.width,renderBox?.height]);

  const setZoomAt=useCallback((next:number,clientX?:number,clientY?:number)=>{
    const viewport=viewportRef.current;const paper=paperRef.current;if(!viewport||!paper){setZoom(clampZoom(next));return;}
    const viewportRect=viewport.getBoundingClientRect();const paperRect=paper.getBoundingClientRect();
    const cx=clientX??(viewportRect.left+viewportRect.width/2);const cy=clientY??(viewportRect.top+viewportRect.height/2);
    zoomAnchorRef.current={x:paperRect.width?Math.max(0,Math.min(1,(cx-paperRect.left)/paperRect.width)):.5,y:paperRect.height?Math.max(0,Math.min(1,(cy-paperRect.top)/paperRect.height)):.5,clientX:cx,clientY:cy};
    setZoom(clampZoom(Number(next.toFixed(3))));
  },[]);

  useEffect(()=>{
    const viewport=viewportRef.current;if(!viewport)return;
    const handleWheel=(event:WheelEvent)=>{
      event.preventDefault();
      setZoomAt(zoom*(event.deltaY<0?1.16:1/1.16),event.clientX,event.clientY);
    };
    viewport.addEventListener('wheel',handleWheel,{passive:false});
    return()=>viewport.removeEventListener('wheel',handleWheel);
  },[zoom,setZoomAt]);

  const fitPage=useCallback(()=>{
    if(!renderBox||!viewportRef.current)return;
    const viewport=viewportRef.current;const baseWidth=renderBox.width/zoom;const baseHeight=renderBox.height/zoom;
    const next=Math.min((viewport.clientWidth-36)/baseWidth,(viewport.clientHeight-36)/baseHeight);
    setZoomAt(next);
  },[renderBox,zoom,setZoomAt]);

  const overlayPoint=useCallback((event:React.PointerEvent<SVGSVGElement>):NormalizedPoint|null=>{
    const rect=event.currentTarget.getBoundingClientRect();if(!rect.width||!rect.height)return null;
    return{x:Math.max(0,Math.min(1,(event.clientX-rect.left)/rect.width)),y:Math.max(0,Math.min(1,(event.clientY-rect.top)/rect.height))};
  },[]);

  const resolvePoint=useCallback((raw:NormalizedPoint,last:NormalizedPoint|null):ResolvedPoint=>{
    if(!renderBox)return{point:raw,snapped:false};
    let point={...raw};let snapped=false;
    const candidates:NormalizedPoint[]=[];
    if(snapEnabled){for(const measurement of currentMeasurements){const geometry=drawingGeometry(measurement.geometry);if(geometry)candidates.push(...geometry.points,...(geometry.holes||[]).flat());}candidates.push(...draftPoints,...calibrationPoints);}
    const snap=(source:NormalizedPoint)=>{
      let nearest:NormalizedPoint|null=null;let nearestPx=SNAP_PX;
      for(const candidate of candidates){const px=Math.hypot((candidate.x-source.x)*renderBox.width,(candidate.y-source.y)*renderBox.height);if(px<nearestPx){nearest=candidate;nearestPx=px;}}
      return nearest;
    };
    if(snapEnabled){const candidate=snap(point);if(candidate){point={...candidate};snapped=true;}}
    if(orthoEnabled&&last){const dx=Math.abs((point.x-last.x)*renderBox.width);const dy=Math.abs((point.y-last.y)*renderBox.height);point=dx>=dy?{x:point.x,y:last.y}:{x:last.x,y:point.y};}
    if(snapEnabled){const candidate=snap(point);if(candidate){const aligned=!last||!orthoEnabled||Math.abs(candidate.x-last.x)*renderBox.width<2||Math.abs(candidate.y-last.y)*renderBox.height<2;if(aligned){point={...candidate};snapped=true;}}}
    return{point,snapped};
  },[renderBox,snapEnabled,orthoEnabled,currentMeasurements,draftPoints,calibrationPoints]);

  const preview=useMemo<DrawingMeasurement|null>(()=>{
    if(!renderBox||!currentSheet)return null;
    if(tool==='cutout'&&selectedGeometry?.type==='polygon'&&draftPoints.length>=3){
      try{const measured=measureDrawingGeometry({...selectedGeometry,holes:[...(selectedGeometry.holes||[]),draftPoints]},renderBox.pdfWidth,renderBox.pdfHeight,selectedCalibration);return{...measured,quantity:roundMeasurement(measured.quantity),perimeterLf:roundMeasurement(measured.perimeterLf)};}catch{return null;}
    }
    if(tool!=='draw'||!selectedAssembly||!draftPoints.length)return null;
    const type=selectedAssembly.primary_measurement==='SF'?'polygon':selectedAssembly.primary_measurement==='EA'?'count':'polyline';
    const required=type==='polygon'?3:type==='polyline'?2:1;if(draftPoints.length<required)return null;
    if(type!=='count'&&!draftCalibration)return null;
    try{const measured=measureDrawingGeometry({type,points:draftPoints} as DrawingGeometry,renderBox.pdfWidth,renderBox.pdfHeight,draftCalibration);return{...measured,quantity:roundMeasurement(measured.quantity),perimeterLf:roundMeasurement(measured.perimeterLf)};}catch{return type==='count'?{quantity:draftPoints.length,unit:'EA',perimeterLf:0}:null;}
  },[draftPoints,renderBox,selectedAssembly,currentSheet,tool,selectedGeometry,selectedCalibration,draftCalibration]);

  const finishDraft=useCallback(async()=>{
    if(locked||busy||!selectedAssembly||!selectedVersion||!currentSheet||!renderBox)return;
    if(!conditionDrawActive){setMessage('Start new scope from Concrete Conditions.');openConditions();return;}
    const geometryType:DrawingGeometry['type']=selectedAssembly.primary_measurement==='SF'?'polygon':selectedAssembly.primary_measurement==='EA'?'count':'polyline';
    const minimum=geometryType==='polygon'?3:geometryType==='polyline'?2:1;
    if(draftPoints.length<minimum){setMessage(`${selectedAssembly.primary_measurement} takeoff needs at least ${minimum} point${minimum===1?'':'s'}.`);return;}
    if(geometryType!=='count'&&!draftScaleRegionId){setMessage('Start the takeoff inside an accepted scale region.');return;}
    const sameAssemblyCount=currentMeasurements.filter((m:any)=>m.assembly_version_id===selectedVersion.id).length;
    const autoName=`${selectedAssembly.name} ${sameAssemblyCount+1}`;
    const finalName=objectName.trim()||autoName;
    setBusy(true);
    try{
      const result=await createDrawingMeasurement({takeoffSetId:takeoffSet.id,sheetId:currentSheet.id,estimateSectionId:null,assemblyVersionId:selectedVersion.id,methodProfileId:selectedMethodProfileId,scaleRegionId:draftScaleRegionId,name:finalName,location:null,drawingReference:null,riskClassCode:riskClassCode||null,variables:variableValues,geometry:{type:geometryType,points:draftPoints}});
      const holdText=result.inputHolds?` · ${result.inputHolds} input hold${result.inputHolds===1?'':'s'}`:'';
      setMessage(`Saved ${finalName} · ${formatTakeoffMeasurement(result.quantity,result.unit)}${result.perimeterLf?` · ${formatArchitecturalLength(result.perimeterLf)} perimeter`:''}${holdText}`);
      setDraftPoints([]);setDraftScaleRegionId(null);setHoverPoint(null);setObjectName('');setSelectedMeasurementId(null);
      setConditionDrawActive(false);setSelectedAssemblyId('');setTool('select');
      router.refresh();
    }catch(error:any){setMessage(error?.message||'Could not save drawing measurement.');}finally{setBusy(false);}
  },[locked,busy,selectedAssembly,selectedVersion,currentSheet,renderBox,draftPoints,draftScaleRegionId,currentMeasurements,objectName,takeoffSet.id,riskClassCode,variableValues,router,selectedMethodProfileId,conditionDrawActive,openConditions]);

  function beginEditMeasurement(measurement:any){
    if(locked)return;
    const geometry=drawingGeometry(measurement?.geometry);if(!geometry)return;
    const copy=copyGeometry(geometry);setSelectedMeasurementId(measurement.id);editOriginalRef.current=copyGeometry(geometry);setEditGeometry(copy);setDraftPoints([]);setInspectorOpen(true);setInspectorTab('properties');setTool('edit');setMessage('Drag a vertex, then press Enter or Save Shape.');
  }
  function beginEdit(){if(!selectedMeasurement)return;beginEditMeasurement(selectedMeasurement);}
  function beginCutout(){if(locked||selectedGeometry?.type!=='polygon')return;setEditGeometry(null);editOriginalRef.current=null;setDraftPoints([]);setHoverPoint(null);setTool('cutout');setMessage('Trace the opening inside the selected area, then press Enter.');}

  async function commitGeometry(kind:GeometryCommandKind,measurementId:string,before:DrawingGeometry,after:DrawingGeometry,success:string){
    if(locked||busy)return false;setBusy(true);
    try{
      const result=await updateDrawingMeasurementGeometry({measurementId,takeoffSetId:takeoffSet.id,geometry:after});
      historyRef.current.record({id:globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random()}`,kind,measurementId,before:copyGeometry(before),after:copyGeometry(after),committedAt:new Date().toISOString()});
      setHistorySnapshot(historyRef.current.snapshot());setMessage(`${success} · ${formatTakeoffMeasurement(result.quantity,result.unit)}`);setEditGeometry(null);editOriginalRef.current=null;setDraftPoints([]);setHoverPoint(null);setTool('select');setSelectedMeasurementId(measurementId);router.refresh();return true;
    }catch(error:any){setMessage(error?.message||'Could not update drawing geometry.');return false;}finally{setBusy(false);}
  }

  async function saveEdit(){if(!selectedMeasurementId||!editGeometry||!editOriginalRef.current)return;await commitGeometry('MoveVertexCommand',selectedMeasurementId,editOriginalRef.current,editGeometry,'Shape updated');}
  async function finishCutout(){if(!selectedMeasurementId||selectedGeometry?.type!=='polygon'||draftPoints.length<3){setMessage('A cutout needs at least three points.');return;}const after:DrawingGeometry={...copyGeometry(selectedGeometry),holes:[...(selectedGeometry.holes||[]).map(hole=>hole.map(point=>({...point}))),draftPoints.map(point=>({...point}))]};await commitGeometry('CreateCutoutCommand',selectedMeasurementId,selectedGeometry,after,'Cutout saved');}
  async function removeLastCutout(){if(!selectedMeasurementId||selectedGeometry?.type!=='polygon'||!selectedGeometry.holes?.length)return;const after=copyGeometry(selectedGeometry);after.holes=after.holes?.slice(0,-1);await commitGeometry('RemoveCutoutCommand',selectedMeasurementId,selectedGeometry,after,'Last cutout removed');}
  async function nudgeSelected(dx:number,dy:number){if(!selectedMeasurementId||!selectedGeometry||locked||busy)return;const after=shiftGeometry(selectedGeometry,dx,dy);await commitGeometry('MoveMeasurementCommand',selectedMeasurementId,selectedGeometry,after,'Takeoff nudged');}

  async function undoCommitted(){const command=historyRef.current.undoCandidate();if(!command||locked||busy)return;setBusy(true);try{await updateDrawingMeasurementGeometry({measurementId:command.measurementId,takeoffSetId:takeoffSet.id,geometry:command.before});historyRef.current.confirmUndo(command.id);setHistorySnapshot(historyRef.current.snapshot());setSelectedMeasurementId(command.measurementId);setMessage(`Undid ${command.kind.replace('Command','').replace(/([A-Z])/g,' $1').trim().toLowerCase()}`);router.refresh();}catch(error:any){setMessage(error?.message||'Could not undo the committed change.');}finally{setBusy(false);}}
  async function redoCommitted(){const command=historyRef.current.redoCandidate();if(!command||locked||busy)return;setBusy(true);try{await updateDrawingMeasurementGeometry({measurementId:command.measurementId,takeoffSetId:takeoffSet.id,geometry:command.after});historyRef.current.confirmRedo(command.id);setHistorySnapshot(historyRef.current.snapshot());setSelectedMeasurementId(command.measurementId);setMessage(`Redid ${command.kind.replace('Command','').replace(/([A-Z])/g,' $1').trim().toLowerCase()}`);router.refresh();}catch(error:any){setMessage(error?.message||'Could not redo the committed change.');}finally{setBusy(false);}}

  useEffect(()=>{
    const down=(event:KeyboardEvent)=>{
      if(props.drawingViewHidden||isTypingTarget(event.target))return;
      if(mobileReview){
        if(event.key==='+'||event.key==='='){event.preventDefault();setZoomAt(zoom*1.2);return;}
        if(event.key==='-'){event.preventDefault();setZoomAt(zoom/1.2);return;}
        if(event.key==='0'){event.preventDefault();setZoomAt(1);return;}
        if(event.key==='1'){event.preventDefault();fitPage();return;}
        if(event.key==='PageUp'){event.preventDefault();changePage(Math.max(1,pageNumber-1));return;}
        if(event.key==='PageDown'){event.preventDefault();changePage(Math.min(pdfPageCount||pageNumber,pageNumber+1));return;}
        return;
      }
      if(event.code==='Space'){event.preventDefault();setSpaceHeld(true);return;}
      if(event.key==='Escape'){cancelTool();return;}
      const commandKey=event.ctrlKey||event.metaKey;
      if(commandKey&&event.key.toLowerCase()==='z'){
        event.preventDefault();
        if(event.shiftKey){void redoCommitted();return;}
        if(draftPoints.length){setDraftPoints(points=>points.slice(0,-1));return;}
        if(calibrationPoints.length){setCalibrationPoints(points=>points.slice(0,-1));return;}
        if(scaleRegionPoints.length){setScaleRegionPoints(points=>points.slice(0,-1));return;}
        void undoCommitted();return;
      }
      if(event.key==='Backspace'&&(draftPoints.length||calibrationPoints.length||scaleRegionPoints.length)){event.preventDefault();if(draftPoints.length)setDraftPoints(points=>points.slice(0,-1));else if(calibrationPoints.length)setCalibrationPoints(points=>points.slice(0,-1));else setScaleRegionPoints(points=>points.slice(0,-1));return;}
      if((event.key==='Delete'||event.key==='Backspace')&&selectedMeasurementId&&!locked){event.preventDefault();void removeSelected();return;}
      if(event.key==='Enter'&&tool==='draw'){event.preventDefault();void finishDraft();return;}
      if(event.key==='Enter'&&tool==='scaleRegion'){event.preventDefault();void savePendingScaleRegion();return;}
      if(event.key==='Enter'&&tool==='cutout'){event.preventDefault();void finishCutout();return;}
      if(event.key==='Enter'&&tool==='edit'){event.preventDefault();void saveEdit();return;}
      if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)&&selectedGeometry&&!locked){event.preventDefault();const step=(event.shiftKey?10:1);const dx=(event.key==='ArrowLeft'?-step:event.key==='ArrowRight'?step:0)/Math.max(1,renderBox?.width||1000);const dy=(event.key==='ArrowUp'?-step:event.key==='ArrowDown'?step:0)/Math.max(1,renderBox?.height||1000);void nudgeSelected(dx,dy);return;}
      if(event.key==='+'||event.key==='='){event.preventDefault();setZoomAt(zoom*1.2);return;}
      if(event.key==='-'){event.preventDefault();setZoomAt(zoom/1.2);return;}
      if(event.key==='0'){event.preventDefault();setZoomAt(1);return;}
      if(event.key==='1'){event.preventDefault();fitPage();return;}
      if(event.key.toLowerCase()==='v')setTool('select');
      if(event.key.toLowerCase()==='h')setTool('pan');
      if(event.key.toLowerCase()==='c'&&!locked){setCalibrationPoints([]);setTool('calibrate');}
      if(event.key.toLowerCase()==='m'&&!locked){openConditions();return;}
      if(event.key.toLowerCase()==='e'&&!locked&&selectedGeometry)beginEdit();
      if(event.key.toLowerCase()==='k'&&!locked&&selectedGeometry?.type==='polygon')beginCutout();
      if(event.key==='PageUp'){event.preventDefault();changePage(Math.max(1,pageNumber-1));}
      if(event.key==='PageDown'){event.preventDefault();changePage(Math.min(pdfPageCount||pageNumber,pageNumber+1));}
      if(event.key.toLowerCase()==='s'){event.preventDefault();setSnapEnabled(v=>!v);}
      if(event.key.toLowerCase()==='o'){event.preventDefault();setOrthoEnabled(v=>!v);}
    };
    const up=(event:KeyboardEvent)=>{if(event.code==='Space')setSpaceHeld(false);};
    window.addEventListener('keydown',down);window.addEventListener('keyup',up);return()=>{window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);};
  },[draftPoints.length,calibrationPoints.length,scaleRegionPoints.length,tool,locked,finishDraft,selectedMeasurementId,selectedGeometry,renderBox,busy,zoom,setZoomAt,fitPage,pageNumber,pdfPageCount,openConditions,props.drawingViewHidden,mobileReview]); // eslint-disable-line react-hooks/exhaustive-deps

  function handlePointerDown(event:React.PointerEvent<SVGSVGElement>){
    if(mobileReview||tool==='pan'||event.button===1||spaceHeld){event.preventDefault();const viewport=viewportRef.current;if(!viewport)return;panRef.current={x:event.clientX,y:event.clientY,left:viewport.scrollLeft,top:viewport.scrollTop};setPanning(true);event.currentTarget.setPointerCapture(event.pointerId);return;}
    if(locked&&tool!=='select')return;
    const raw=overlayPoint(event);if(!raw)return;
    const last=tool==='calibrate'?(calibrationPoints.at(-1)||null):tool==='scaleRegion'?(scaleRegionPoints.at(-1)||null):(draftPoints.at(-1)||null);const resolved=resolvePoint(raw,last);
    if(tool==='calibrate'){setCalibrationPoints(points=>points.length>=2?[resolved.point]:[...points,resolved.point]);return;}
    if(tool==='scaleRegion'){setScaleRegionPoints(points=>points.length>=2?[resolved.point]:[...points,resolved.point]);return;}
    if(tool==='draw'){if(!conditionDrawActive){setMessage('Start new scope from Concrete Conditions.');openConditions();return;}if(!selectedAssembly){setMessage('Concrete Condition geometry is not ready. Reopen Conditions and start the required takeoff.');return;}if(selectedAssembly.primary_measurement!=='EA'){const region=findScaleRegionForPoint(currentScaleRegions,resolved.point);if(!region){setMessage('Confirm or create a scale region covering this point.');return;}if(draftScaleRegionId&&draftScaleRegionId!==region.id){setMessage('One takeoff cannot cross between different scale regions.');return;}setDraftScaleRegionId(region.id);}setDraftPoints(points=>[...points,resolved.point]);return;}
    if(tool==='cutout'){if(selectedGeometry?.type!=='polygon'){setMessage('Select an area takeoff before adding a cutout.');setTool('select');return;}setDraftPoints(points=>[...points,resolved.point]);return;}
    if(tool==='select'){setSelectedMeasurementId(null);setEditGeometry(null);editOriginalRef.current=null;}
  }
  function handlePointerMove(event:React.PointerEvent<SVGSVGElement>){
    if(panRef.current&&panning){const viewport=viewportRef.current;if(!viewport)return;viewport.scrollLeft=panRef.current.left-(event.clientX-panRef.current.x);viewport.scrollTop=panRef.current.top-(event.clientY-panRef.current.y);return;}
    if(tool==='draw'||tool==='calibrate'||tool==='scaleRegion'||tool==='cutout'){const raw=overlayPoint(event);if(!raw)return;const last=tool==='calibrate'?(calibrationPoints.at(-1)||null):tool==='scaleRegion'?(scaleRegionPoints.at(-1)||null):(draftPoints.at(-1)||null);const resolved=resolvePoint(raw,last);setHoverPoint(resolved.point);setHoverSnapped(resolved.snapped);}
  }
  function handlePointerUp(event:React.PointerEvent<SVGSVGElement>){if(panRef.current){panRef.current=null;setPanning(false);try{event.currentTarget.releasePointerCapture(event.pointerId);}catch{}}}

  async function persistScaleRegion(candidate:ScaleCandidate|null,calibration:ScaleCalibration,regionBounds:any,isDefault:boolean){
    if(locked||busy||!currentSheet)return;setBusy(true);
    try{const result=await saveTakeoffScaleRegion({takeoffSetId:takeoffSet.id,sheetId:currentSheet.id,name:isDefault?`${currentSheet.sheet_number||`Page ${currentSheet.page_number}`} Scale`:`${currentSheet.sheet_number||`Page ${currentSheet.page_number}`} · ${candidate?.label||calibration.scale_label} Region ${currentScaleRegions.filter(region=>!region.is_default).length+1}`,regionBounds,scaleLabel:candidate?.label||calibration.scale_label,scaleKind:candidate?.scaleKind==='nts'?'manual':candidate?.scaleKind||'manual',sourceType:candidate?'pdf_text':'manual',sourceText:candidate?.sourceText||null,sourceBounds:candidate?.sourceBounds||null,confidence:candidate?.confidence||null,calibration,isDefault});setMessage(`Scale ${candidate?.label||calibration.scale_label} saved${result.recalculated?` · ${result.recalculated} takeoff recalculated`:''}`);setCalibrationPoints([]);setScaleRegionPoints([]);setPendingScaleCandidate(null);setPendingManualCalibration(null);setDraftScaleRegionId(null);setHoverPoint(null);setTool('select');router.refresh();}catch(error:any){setMessage(error?.message||'Could not save drawing scale.');}finally{setBusy(false);}
  }
  async function useDetectedScaleSheet(candidate:ScaleCandidate){try{await persistScaleRegion(candidate,calibrationFromDetectedScale(candidate),null,true);}catch(error:any){setMessage(error?.message||'Detected scale is invalid.');}}
  function beginDetectedScaleRegion(candidate:ScaleCandidate){try{calibrationFromDetectedScale(candidate);setPendingScaleCandidate(candidate);setPendingManualCalibration(null);setScaleRegionPoints([]);setCalibrationPoints([]);setTool('scaleRegion');setMessage(`Pick two corners for ${candidate.label}.`);}catch(error:any){setMessage(error?.message||'Detected scale is invalid.');}}
  function manualCalibration(){if(!currentSheet||!renderBox)throw new Error('Drawing sheet is not ready.');return calibrationFromManual(calibrationPoints,Number(knownDistanceFt),renderBox.pdfWidth,renderBox.pdfHeight);}
  async function useManualScaleSheet(){try{await persistScaleRegion(null,manualCalibration(),null,true);}catch(error:any){setMessage(error?.message||'Manual calibration is invalid.');}}
  function beginManualScaleRegion(){try{const calibration=manualCalibration();setPendingManualCalibration(calibration);setPendingScaleCandidate(null);setScaleRegionPoints([]);setTool('scaleRegion');setMessage('Pick two corners for the manually calibrated scale region.');}catch(error:any){setMessage(error?.message||'Manual calibration is invalid.');}}
  async function savePendingScaleRegion(){const bounds=boundsFromPoints(scaleRegionPoints);if(!bounds){setMessage('Pick two opposite corners for the scale region.');return;}try{if(pendingScaleCandidate)await persistScaleRegion(pendingScaleCandidate,calibrationFromDetectedScale(pendingScaleCandidate),bounds,false);else if(pendingManualCalibration)await persistScaleRegion(null,pendingManualCalibration,bounds,false);else setMessage('Choose a detected or manual scale first.');}catch(error:any){setMessage(error?.message||'Could not save scale region.');}}
  function cancelScaleRegion(){setScaleRegionPoints([]);setPendingScaleCandidate(null);setPendingManualCalibration(null);setHoverPoint(null);setTool('select');}
  async function removeScaleRegion(region:TakeoffScaleRegion){if(locked||busy)return;setBusy(true);try{await deleteTakeoffScaleRegion(region.id,takeoffSet.id);setMessage(`Removed ${region.name}`);router.refresh();}catch(error:any){setMessage(error?.message||'Could not remove scale region.');}finally{setBusy(false);}}
  async function removeSelected(){
    if(!selectedMeasurementId||locked||busy)return;setBusy(true);try{await deleteDrawingMeasurement(selectedMeasurementId,takeoffSet.id);historyRef.current.clear();setHistorySnapshot(historyRef.current.snapshot());setMessage('Takeoff object and generated estimate lines removed');setSelectedMeasurementId(null);setEditGeometry(null);editOriginalRef.current=null;router.refresh();}catch(error:any){setMessage(error?.message||'Could not delete object.');}finally{setBusy(false);}
  }
  function changePage(next:number){setPageNumber(next);setDraftPoints([]);setDraftScaleRegionId(null);setCalibrationPoints([]);setScaleRegionPoints([]);setPendingScaleCandidate(null);setPendingManualCalibration(null);setEditGeometry(null);editOriginalRef.current=null;setHoverPoint(null);setSelectedMeasurementId(null);setConditionDrawActive(false);setSelectedAssemblyId('');setTool(mobileReview?'pan':'select');setZoom(1);if(mobileReview)window.dispatchEvent(new Event('carez:mobile-sheet-selected'));}
  function cancelTool(){setDraftPoints([]);setDraftScaleRegionId(null);setCalibrationPoints([]);setScaleRegionPoints([]);setPendingScaleCandidate(null);setPendingManualCalibration(null);setEditGeometry(null);editOriginalRef.current=null;setHoverPoint(null);setConditionDrawActive(false);setSelectedAssemblyId('');setTool(mobileReview?'pan':'select');}

  const pageEntries=Array.from({length:pdfPageCount||initialSheets.length||1},(_,index)=>{const number=index+1;return initialSheets.find((s:any)=>Number(s.page_number)===number)||{id:`pending-${number}`,page_number:number,scale_status:'uncalibrated'};});
  const overlayClass=(tool==='pan'||spaceHeld)?(panning?styles.overlayPanning:styles.overlayPan):tool==='select'?styles.overlaySelect:'';
  const workingPoints=tool==='draw'||tool==='cutout'?draftPoints:tool==='scaleRegion'?scaleRegionPoints:calibrationPoints;
  const draftRenderPoints=hoverPoint&&(tool==='draw'||tool==='calibrate'||tool==='scaleRegion'||tool==='cutout')?[...workingPoints,hoverPoint]:workingPoints;
  const zoomPercent=Math.round(zoom*100);
  const qualityLimited=renderQuality<.98;
  const selectedVersionRecord:any=selectedMeasurement?versionMap.get(selectedMeasurement.assembly_version_id):null;
  const selectedAssemblyRecord:any=selectedVersionRecord?assemblyMap.get(selectedVersionRecord.assembly_id):null;
  const selectedColor=hashColor(selectedAssemblyRecord?.code||selectedMeasurement?.id||'selected');

  return <div className={styles.workstation} data-mobile-review={mobileReview?'true':'false'}>
  <div className={`${styles.workspace} ${styles.noSheets} ${!inspectorOpen?styles.noInspector:''}`}>

    <section className={styles.center} inert={props.drawingViewHidden} aria-hidden={props.drawingViewHidden||undefined}>
      <div className={styles.toolbar}>
        {mobileReview?<><div className={styles.mobileReviewTools}>
          <button type="button" className={`${styles.toolButton} ${styles.toolButtonActive}`} title="Pan plan"><Hand size={16}/><span>Pan</span></button>
        </div>
        <div className={styles.toolbarSpacer}/>
        <label className={styles.pageSelect}><span>Select Pages</span><select aria-label="Select Pages" value={pageNumber} onChange={event=>changePage(Number(event.target.value))}>{pageEntries.map((sheet:any)=><option key={sheet.page_number} value={sheet.page_number}>{sheetDisplayLabel(sheet)}</option>)}</select></label>
        <div className={styles.zoomGroup}>
          <button type="button" className={styles.iconTool} title="Zoom out" onClick={()=>setZoomAt(zoom/1.2)}><Minus size={15}/></button>
          <button type="button" className={styles.zoomLabel} title="Reset zoom" onClick={()=>setZoomAt(1)}>{zoomPercent}%</button>
          <button type="button" className={styles.iconTool} title="Zoom in" onClick={()=>setZoomAt(zoom*1.2)}><Plus size={15}/></button>
          <button type="button" className={styles.iconTool} title="Fit page" onClick={fitPage}><Maximize size={15}/></button>
        </div></>:<>
        <div className={styles.toolGroup}>
          <label className={styles.pageSelect}><span>Select Pages</span><select aria-label="Select Pages" value={pageNumber} onChange={event=>changePage(Number(event.target.value))}>{pageEntries.map((sheet:any)=><option key={sheet.page_number} value={sheet.page_number}>{sheetDisplayLabel(sheet)}</option>)}</select></label>
          <button type="button" title="Select · V" className={`${styles.toolButton} ${tool==='select'?styles.toolButtonActive:''}`} onClick={()=>setTool('select')}><MousePointer2 size={16}/><span>Select</span></button>
          <button type="button" title="Pan · H or hold Space" className={`${styles.toolButton} ${tool==='pan'?styles.toolButtonActive:''}`} onClick={()=>setTool('pan')}><Hand size={16}/><span>Pan</span></button>
          <button type="button" disabled={locked} title="Set drawing scale · C" className={`${styles.toolButton} ${tool==='calibrate'?styles.toolButtonActive:''}`} onClick={()=>{setCalibrationPoints([]);setInspectorTab('properties');setTool('calibrate');}}><Ruler size={16}/><span>Scale</span></button>
          <button type="button" disabled={locked} title="Concrete Conditions · M" className={`${styles.toolButton} ${styles.measureButton}`} onClick={openConditions}><Crosshair size={16}/><span>Conditions</span></button>
          <button type="button" disabled={locked||!selectedGeometry} title="Edit selected shape · E" className={`${styles.toolButton} ${tool==='edit'?styles.toolButtonActive:''}`} onClick={beginEdit}><Pencil size={15}/><span>Edit</span></button>
          <button type="button" disabled={locked||selectedGeometry?.type!=='polygon'} title="Add area cutout · K" className={`${styles.toolButton} ${tool==='cutout'?styles.toolButtonActive:''}`} onClick={beginCutout}><Scissors size={15}/><span>Cutout</span></button>
        </div>

        <div className={styles.toolGroup}>
          <button type="button" className={`${styles.toolButton} ${snapEnabled?styles.toggleActive:''}`} title="Snap to existing takeoff vertices · S" onClick={()=>setSnapEnabled(v=>!v)}><Magnet size={15}/><span>Snap</span></button>
          <button type="button" className={`${styles.toolButton} ${orthoEnabled?styles.toggleActive:''}`} title="Constrain horizontal/vertical · O" onClick={()=>setOrthoEnabled(v=>!v)}><MoveHorizontal size={15}/><span>Ortho</span></button>
          <button type="button" disabled={busy||(!draftPoints.length&&!calibrationPoints.length&&!scaleRegionPoints.length&&!historySnapshot.canUndo)} className={styles.toolButton} title="Undo point or committed geometry · Ctrl/Cmd+Z" onClick={()=>{if(tool==='calibrate'&&calibrationPoints.length)setCalibrationPoints(points=>points.slice(0,-1));else if(tool==='scaleRegion'&&scaleRegionPoints.length)setScaleRegionPoints(points=>points.slice(0,-1));else if(draftPoints.length)setDraftPoints(points=>points.slice(0,-1));else void undoCommitted();}}><Undo2 size={15}/></button>
          <button type="button" disabled={busy||!historySnapshot.canRedo} className={styles.toolButton} title="Redo committed geometry · Ctrl/Cmd+Shift+Z" onClick={()=>void redoCommitted()}><Redo2 size={15}/></button>
          {tool==='scaleRegion'&&<button type="button" disabled={busy||scaleRegionPoints.length!==2} className={`${styles.toolButton} ${styles.finishButton}`} title="Save scale region · Enter" onClick={()=>void savePendingScaleRegion()}><Check size={15}/><span>Save Region</span></button>}
          {tool==='draw'&&<button type="button" disabled={busy||!draftPoints.length} className={`${styles.toolButton} ${styles.finishButton}`} title="Finish measurement · Enter or right-click" onClick={()=>void finishDraft()}><Check size={15}/><span>Finish</span></button>}
          {tool==='cutout'&&<button type="button" disabled={busy||draftPoints.length<3} className={`${styles.toolButton} ${styles.finishButton}`} title="Save cutout · Enter or right-click" onClick={()=>void finishCutout()}><Check size={15}/><span>Subtract</span></button>}
          {tool==='edit'&&<button type="button" disabled={busy||!editGeometry} className={`${styles.toolButton} ${styles.finishButton}`} title="Save shape · Enter" onClick={()=>void saveEdit()}><Check size={15}/><span>Save</span></button>}
          {(tool==='draw'||tool==='calibrate'||tool==='scaleRegion'||tool==='cutout'||tool==='edit')&&<button type="button" className={styles.toolButton} title="Cancel active tool · Escape" onClick={cancelTool}><X size={15}/></button>}
        </div>

        <div className={styles.toolbarSpacer}/>
        <output className={styles.scaleTelemetry}>SCALE CALIBRATION // CANONICAL AUTHORITY: {currentScaleLabel}</output>
        <div className={styles.zoomGroup}>
          <button type="button" className={styles.iconTool} title="Zoom out" onClick={()=>setZoomAt(zoom/1.2)}><Minus size={15}/></button>
          <button type="button" className={styles.zoomLabel} title={qualityLimited?'Display zoom exceeds full-resolution render budget. Geometry remains exact.':'Zoom'} onClick={()=>setZoomAt(1)}>{zoomPercent}%{qualityLimited&&<i>HQ</i>}</button>
          <button type="button" className={styles.iconTool} title="Zoom in" onClick={()=>setZoomAt(zoom*1.2)}><Plus size={15}/></button>
          <button type="button" className={styles.iconTool} title="Fit width · 0" onClick={()=>setZoomAt(1)}><RotateCcw size={15}/></button>
          <button type="button" className={styles.iconTool} title="Fit page · 1" onClick={fitPage}><Maximize size={15}/></button>
          {!inspectorOpen&&<button type="button" className={styles.iconTool} title="Show takeoff inspector" onClick={()=>setInspectorOpen(true)}><PanelRightOpen size={16}/></button>}
        </div>
        </>}
      </div>

      <div ref={viewportRef} className={styles.canvasViewport}>
        {!renderBox&&<div className={styles.loading}>{message}</div>}
        <div ref={paperRef} className={styles.paper} style={renderBox?{width:renderBox.width,height:renderBox.height}:{width:1,height:1}}>
          <canvas ref={canvasRef} className={styles.pdfCanvas}/>
          {renderBox&&<svg className={`${styles.overlay} ${overlayClass}`} viewBox={`0 0 ${renderBox.pdfWidth} ${renderBox.pdfHeight}`} onPointerDown={handlePointerDown} onPointerMove={handlePointerMove} onPointerUp={handlePointerUp} onPointerCancel={handlePointerUp} onPointerLeave={()=>{if(!panning){setHoverPoint(null);setHoverSnapped(false);}}} onContextMenu={event=>{event.preventDefault();if(tool==='draw')void finishDraft();if(tool==='cutout')void finishCutout();}}>
            <TakeoffScaleOverlay regions={currentScaleRegions} pendingCandidate={pendingScaleCandidate} regionPoints={scaleRegionPoints} pageWidth={renderBox.pdfWidth} pageHeight={renderBox.pdfHeight}/>
            {currentMeasurements.map((measurement:any)=>{
              if(props.conditionPresentation?.hiddenMeasurementIds.includes(measurement.id))return null;
              const stored=drawingGeometry(measurement.geometry);if(!stored)return null;const selected=selectedMeasurementId===measurement.id;const geometry=selected&&tool==='edit'&&editGeometry?editGeometry:stored;const points=geometry.points;const version:any=versionMap.get(measurement.assembly_version_id);const assembly:any=version?assemblyMap.get(version.assembly_id):null;const style=resolveDisplayStyle(assembly?.display_style,hashColor(assembly?.code||measurement.assembly_version_id||measurement.id));const color=props.conditionPresentation?.colors[measurement.id]||style.color;const coords=points.map(point=>`${point.x*renderBox.pdfWidth},${point.y*renderBox.pdfHeight}`).join(' ');const scaleRegion=scaleRegionMap.get(measurement.scale_region_id);const measurementCalibration=scaleRegion?.calibration||currentSheet?.calibration;const physical=physicalFootprint(points,version,measurement.variables,measurementCalibration,renderBox,measurement.geometry_anchor,measurement.geometry_offset_in);const physicalCoords=physical.map(point=>`${point.x*renderBox.pdfWidth},${point.y*renderBox.pdfHeight}`).join(' ');const onSelect=(event:React.MouseEvent)=>{if(tool==='select'){event.stopPropagation();setSelectedMeasurementId(measurement.id);setEditGeometry(null);editOriginalRef.current=null;setInspectorTab('properties');}};
              return <g key={measurement.id} className={styles.measurementShape} data-selected={selected} onClick={onSelect} style={{cursor:tool==='select'?'pointer':undefined}}>
                {geometry.type==='polygon'&&<path d={geometryPath(geometry,renderBox.pdfWidth,renderBox.pdfHeight)} fill={`${color}24`} fillRule="evenodd" stroke={color} strokeWidth={selected?3.2:2} vectorEffect="non-scaling-stroke"/>}
                {physical.length>=3&&<polygon points={physicalCoords} fill={`${style.color}${Math.round(style.opacity*255).toString(16).padStart(2,'0')}`} stroke={style.borderColor} strokeWidth={selected?style.borderWidth+1:style.borderWidth} strokeDasharray={style.pattern==='dashed'?'6 4':undefined} vectorEffect="non-scaling-stroke"/>}{geometry.type==='polyline'&&<polyline points={coords} fill="none" stroke={color} strokeWidth={selected?4:2.5} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke"/>}
                {geometry.type==='count'&&points.map((point,index)=><g key={index}><circle cx={point.x*renderBox.pdfWidth} cy={point.y*renderBox.pdfHeight} r={selected?6:5} fill={`${color}45`} stroke={color} strokeWidth="2" vectorEffect="non-scaling-stroke"/><line x1={point.x*renderBox.pdfWidth-5} y1={point.y*renderBox.pdfHeight} x2={point.x*renderBox.pdfWidth+5} y2={point.y*renderBox.pdfHeight} stroke={color} vectorEffect="non-scaling-stroke"/><line x1={point.x*renderBox.pdfWidth} y1={point.y*renderBox.pdfHeight-5} x2={point.x*renderBox.pdfWidth} y2={point.y*renderBox.pdfHeight+5} stroke={color} vectorEffect="non-scaling-stroke"/></g>)}
              </g>;
            })}

            <TakeoffMeasurementHoverOverlay
              measurements={currentMeasurements}
              outputs={measurementSummaries}
              assemblies={assemblies}
              versions={versions}
              pageWidth={renderBox.pdfWidth}
              pageHeight={renderBox.pdfHeight}
              tool={tool}
              panning={panning}
              spaceHeld={spaceHeld}
              viewportRef={viewportRef}
              onSelectMeasurement={measurement=>{setSelectedMeasurementId(measurement.id);setEditGeometry(null);editOriginalRef.current=null;setInspectorOpen(true);setInspectorTab('properties');}}
              onEditMeasurement={beginEditMeasurement}
            />

            {tool==='edit'&&editGeometry&&selectedMeasurement&&<TakeoffVertexEditor geometry={editGeometry} pageWidth={renderBox.pdfWidth} pageHeight={renderBox.pdfHeight} color={selectedColor} onChange={setEditGeometry}/>}

            {tool==='draw'&&draftRenderPoints.length>0&&<g pointerEvents="none">
              {selectedAssembly?.primary_measurement==='SF'&&draftRenderPoints.length>=2&&<polygon points={draftRenderPoints.map(p=>`${p.x*renderBox.pdfWidth},${p.y*renderBox.pdfHeight}`).join(' ')} fill="rgba(66,111,147,.13)" stroke="#426F93" strokeWidth="2" strokeDasharray="7 5" vectorEffect="non-scaling-stroke"/>}
              {selectedAssembly?.primary_measurement==='LF'&&draftRenderPoints.length>=2&&<><polygon points={physicalFootprint(draftRenderPoints,selectedVersion,variableValues,draftCalibration,renderBox).map(point=>`${point.x*renderBox.pdfWidth},${point.y*renderBox.pdfHeight}`).join(' ')} fill="rgba(66,111,147,.22)" stroke="#426F93" strokeWidth="1.5" vectorEffect="non-scaling-stroke"/><polyline points={draftRenderPoints.map(p=>`${p.x*renderBox.pdfWidth},${p.y*renderBox.pdfHeight}`).join(' ')} fill="none" stroke="#426F93" strokeWidth="2.5" strokeDasharray="7 5" vectorEffect="non-scaling-stroke"/></>}
              {draftPoints.map((p,i)=><circle key={i} cx={p.x*renderBox.pdfWidth} cy={p.y*renderBox.pdfHeight} r="4" fill="#426F93" stroke="#171B19" strokeWidth="1.5" vectorEffect="non-scaling-stroke"/>)}
            </g>}
            {tool==='cutout'&&draftRenderPoints.length>0&&<g pointerEvents="none">
              {draftRenderPoints.length>=2&&<polygon points={draftRenderPoints.map(point=>`${point.x*renderBox.pdfWidth},${point.y*renderBox.pdfHeight}`).join(' ')} fill="rgba(138,97,11,.16)" stroke="#8A610B" strokeWidth="2" strokeDasharray="7 5" vectorEffect="non-scaling-stroke"/>}
              {draftPoints.map((point,index)=><circle key={index} cx={point.x*renderBox.pdfWidth} cy={point.y*renderBox.pdfHeight} r="4" fill="#8A610B" stroke="#171B19" strokeWidth="1.5" vectorEffect="non-scaling-stroke"/>)}
            </g>}
            {tool==='calibrate'&&draftRenderPoints.length>0&&<g pointerEvents="none">{draftRenderPoints.length>=2&&<line x1={draftRenderPoints[0].x*renderBox.pdfWidth} y1={draftRenderPoints[0].y*renderBox.pdfHeight} x2={draftRenderPoints[1].x*renderBox.pdfWidth} y2={draftRenderPoints[1].y*renderBox.pdfHeight} stroke="#8A610B" strokeWidth="2.5" strokeDasharray="7 5" vectorEffect="non-scaling-stroke"/>}{calibrationPoints.map((p,i)=><circle key={i} cx={p.x*renderBox.pdfWidth} cy={p.y*renderBox.pdfHeight} r="5" fill="#8A610B" stroke="#171B19" strokeWidth="2" vectorEffect="non-scaling-stroke"/>)}</g>}
            {hoverPoint&&(tool==='draw'||tool==='calibrate'||tool==='scaleRegion'||tool==='cutout')&&<g pointerEvents="none" transform={`translate(${hoverPoint.x*renderBox.pdfWidth} ${hoverPoint.y*renderBox.pdfHeight})`}><circle r={hoverSnapped?7:4.5} fill="none" stroke={hoverSnapped?'#009966':tool==='cutout'?'#8A610B':'#426F93'} strokeWidth="1.5" vectorEffect="non-scaling-stroke"/><line x1="-12" x2="12" y1="0" y2="0" stroke={hoverSnapped?'#009966':tool==='cutout'?'#8A610B':'#426F93'} strokeWidth="1" vectorEffect="non-scaling-stroke"/><line y1="-12" y2="12" x1="0" x2="0" stroke={hoverSnapped?'#009966':tool==='cutout'?'#8A610B':'#426F93'} strokeWidth="1" vectorEffect="non-scaling-stroke"/></g>}
          </svg>}
        </div>
        {preview&&<div className={`${styles.liveReadout} ${tool==='cutout'?styles.cutoutReadout:''}`}><strong>{formatTakeoffMeasurement(preview.quantity,preview.unit)}</strong>{tool==='cutout'&&Number(preview.cutoutQuantity||0)>0?<span>net · {qty(preview.cutoutQuantity)} SF excluded</span>:preview.perimeterLf>0&&<span>{formatArchitecturalLength(preview.perimeterLf)} perimeter</span>}</div>}
        {currentSheet&&currentMeasurements.length===0&&<div className={styles.emptyTelemetry}>0 structural takeoffs traced on this sheet. Select a Condition blueprint module above to begin tracing geometries.</div>}
      </div>

      {mobileReview?<div className={styles.statusbar}><span><strong>Page {pageNumber}</strong> / {pdfPageCount||'…'}</span><span className={currentScale?styles.statusOk:styles.statusHold}>{currentScale?'Scale set':'Scale required'}</span><span className={styles.mobileReviewStatus}>Review only</span></div>:<div className={styles.statusbar}><span><strong>Page {pageNumber}</strong> / {pdfPageCount||'…'}</span><span className={currentScale?styles.statusOk:styles.statusHold}>{currentScale?`${currentScaleRegions.length||1} scale${(currentScaleRegions.length||1)===1?'':'s'} set`:'Scale required'}</span><span>{snapEnabled?'Snap on':'Snap off'} · {orthoEnabled?'Ortho on':'Ortho off'}</span><span className={styles.statusHint}>{tool==='draw'?'Click points · Enter/right-click to finish':tool==='scaleRegion'?'Pick two opposite region corners · Enter to save':tool==='cutout'?'Trace opening · Enter/right-click to subtract':tool==='edit'?'Drag vertices · Enter to save':'Wheel zoom · Space/middle mouse pan · Arrows nudge selection'}</span><span className={styles.statusMessage}>{message}</span></div>}
    </section>

    {inspectorOpen&&<aside className={styles.inspector}>
      <div className={styles.panelHeader}><div><div className={styles.panelTitle}>Inspector</div><div className={styles.panelMeta}>{currentSheet?`${sheetDisplayLabel(currentSheet)} · ${currentMeasurements.length} takeoff${currentMeasurements.length===1?'':'s'}`:'Preparing sheet'}</div></div><button type="button" className={styles.iconButton} title="Hide inspector" onClick={()=>setInspectorOpen(false)}><PanelRightClose size={16}/></button></div>
      <div className={styles.inspectorTabs} role="tablist" aria-label="Takeoff inspector">
        <button type="button" role="tab" aria-selected={inspectorTab==='takeoffs'} className={inspectorTab==='takeoffs'?styles.inspectorTabActive:''} onClick={()=>setInspectorTab('takeoffs')}>Takeoffs</button>
        <button type="button" role="tab" aria-selected={inspectorTab==='properties'} className={inspectorTab==='properties'?styles.inspectorTabActive:''} onClick={()=>setInspectorTab('properties')}>Properties</button>
      </div>
      <div className={styles.inspectorBody}>
        {inspectorTab==='takeoffs'&&<>
          <div className={styles.group}>
            <div className={styles.groupHead}><div><div className={styles.groupTitle}>Concrete Conditions</div><div className={styles.groupHelp}>Create or open a Condition, then draw the geometry it requires.</div></div></div>
            {!locked&&<button type="button" className={styles.measurePrimary} onClick={openConditions}><Crosshair size={16}/> Open Concrete Conditions</button>}
          </div>

          <div className={styles.group}><div className={styles.groupTitle}>This Sheet</div>{currentMeasurements.length?<div className={styles.objectList}>{currentMeasurements.map((measurement:any)=>{const version:any=versionMap.get(measurement.assembly_version_id);const assembly:any=version?assemblyMap.get(version.assembly_id):null;const summary=summaryMap.get(measurement.id);const geometry=drawingGeometry(measurement.geometry);return <button type="button" key={measurement.id} className={`${styles.objectButton} ${selectedMeasurementId===measurement.id?styles.objectSelected:''}`} onClick={()=>{setSelectedMeasurementId(measurement.id);setEditGeometry(null);editOriginalRef.current=null;setTool('select');setInspectorTab('properties');}}><span className={styles.objectColor} style={{background:hashColor(assembly?.code||measurement.id)}}/><span><strong>{measurement.name}</strong><small>{conditionMeasurementIdSet.has(measurement.id)?'Concrete Condition':'Historical takeoff'} · {formatTakeoffMeasurement(measurement.raw_quantity,measurement.raw_unit)}{geometry?.holes?.length?` · ${geometry.holes.length} cutout${geometry.holes.length===1?'':'s'}`:''}</small></span>{summary?.missing?<b className={styles.objectWarn}>!</b>:null}</button>;})}</div>:<div className={styles.emptySmall}>No takeoff on this sheet yet.</div>}</div>


        </>}

        {inspectorTab==='properties'&&<>
          <TakeoffScalePanel
            regions={currentScaleRegions}
            candidates={visibleScaleCandidates}
            detectionStatus={scaleDetectionStatus}
            locked={locked}
            busy={busy}
            knownDistanceFt={knownDistanceFt}
            calibrationPointCount={calibrationPoints.length}
            pendingCandidate={pendingScaleCandidate}
            pendingManualLabel={pendingManualCalibration?.scale_label||null}
            regionPointCount={scaleRegionPoints.length}
            onKnownDistanceChange={setKnownDistanceFt}
            onUseDetectedSheet={candidate=>void useDetectedScaleSheet(candidate)}
            onAssignDetectedRegion={beginDetectedScaleRegion}
            onPickManual={()=>{setCalibrationPoints([]);setScaleRegionPoints([]);setPendingScaleCandidate(null);setPendingManualCalibration(null);setTool('calibrate');}}
            onUseManualSheet={()=>void useManualScaleSheet()}
            onAssignManualRegion={beginManualScaleRegion}
            onSaveRegion={()=>void savePendingScaleRegion()}
            onCancelRegion={cancelScaleRegion}
            onDeleteRegion={region=>void removeScaleRegion(region)}
          />

          {selectedMeasurement?<div className={`${styles.group} ${styles.selectedGroup}`}>
            <div className={styles.groupTitle}>Selected Takeoff</div><div className={styles.selectedTitle}>{selectedMeasurement.name}</div><div className={styles.selectedQty}>{formatTakeoffMeasurement(selectedMeasurement.raw_quantity,selectedMeasurement.raw_unit)}</div>
            {selectedGeometry?.type==='polygon'&&<div className={styles.cutoutSummary}><span><b>{selectedCutoutCount}</b> cutout{selectedCutoutCount===1?'':'s'}</span><span><b>{qty(selectedMeasurement.geometry?.cutout_quantity||0)}</b> SF excluded</span><span><b>{formatArchitecturalLength(selectedMeasurement.geometry?.perimeter_lf||0)}</b> edge</span></div>}
            {selectedSummary&&<div className={styles.selectedStats}><span><b>{qty(selectedSummary.mh)}</b> MH</span><span><b>{money(selectedSummary.cost)}</b> direct</span></div>}
            {selectedSummary?.inputHolds?<div className={styles.statusWarn}>{selectedSummary.inputHolds} generated line{selectedSummary.inputHolds===1?'':'s'} waiting on required Condition input. Geometry and unaffected quantities are saved.</div>:null}
            {selectedSummary?.priceHolds?<div className={styles.statusWarn}>{selectedSummary.priceHolds} generated line{selectedSummary.priceHolds===1?'':'s'} still need pricing or a labor rate.</div>:null}
            <div className={styles.statusWarn}>{conditionMeasurementIdSet.has(selectedMeasurement.id)?'Condition-managed takeoff. Plan facts, methods, production, and modules are edited in Concrete Conditions.':'Historical takeoff preserved for lineage. New scope is authored through Concrete Conditions.'}</div>
            {!locked&&<div className={styles.proActionGrid}>{tool==='edit'?<><button type="button" className={styles.primary} disabled={busy} onClick={()=>void saveEdit()}><Check size={14}/> Save Shape</button><button type="button" className={styles.secondary} onClick={cancelTool}><X size={14}/> Cancel</button></>:<><button type="button" className={styles.secondary} onClick={beginEdit}><Pencil size={14}/> Edit Shape</button>{selectedGeometry?.type==='polygon'&&<button type="button" className={styles.secondary} onClick={beginCutout}><Scissors size={14}/> Add Cutout</button>}{selectedCutoutCount>0&&<button type="button" className={styles.secondary} disabled={busy} onClick={()=>void removeLastCutout()}><Undo2 size={14}/> Remove Last</button>}</>}</div>}
            {tool==='cutout'&&preview&&<div className={`${styles.previewCard} ${styles.cutoutPreview}`}><span>Net concrete</span><strong>{qty(preview.quantity)} SF</strong><small>{qty(preview.cutoutQuantity||0)} SF total excluded</small><button type="button" disabled={busy||draftPoints.length<3} onClick={()=>void finishCutout()}><Scissors size={15}/> Save cutout</button></div>}
            {!locked&&<button type="button" className={styles.danger} disabled={busy} onClick={()=>void removeSelected()}><Trash2 size={14}/> Delete takeoff</button>}
          </div>:<div className={styles.group}><div className={styles.groupTitle}>New Takeoff</div><div className={styles.groupHelp}>New measured scope starts from a Concrete Condition so geometry, modules, outputs, and estimate lineage stay together.</div>{!locked&&<button type="button" className={styles.measurePrimary} onClick={openConditions}><Crosshair size={16}/> Open Concrete Conditions</button>}</div>}

          <details className={styles.shortcuts}><summary>Keyboard & mouse shortcuts</summary><div className={styles.shortcutGrid}><kbd>Wheel</kbd><span>Zoom at cursor</span><kbd>Space</kbd><span>Temporary pan</span><kbd>M</kbd><span>Open Conditions</span><kbd>E</kbd><span>Edit selected shape</span><kbd>K</kbd><span>Add area cutout</span><kbd>Arrows</kbd><span>Nudge selected · Shift × 10</span><kbd>Ctrl Z</kbd><span>Undo committed geometry</span><kbd>Ctrl ⇧ Z</kbd><span>Redo committed geometry</span><kbd>PgUp/Dn</kbd><span>Previous / next sheet</span><kbd>S / O</kbd><span>Snap / ortho</span><kbd>Enter</kbd><span>Finish or save</span><kbd>Esc</kbd><span>Cancel tool</span></div></details>
        </>}
      </div>
    </aside>}
  </div>
  {!mobileReview&&<TakeoffQuantityDock
    measurements={initialMeasurements}
    outputs={measurementSummaries}
    assemblies={assemblies}
    versions={versions}
    sections={sections}
    sheets={initialSheets}
    currentSheetId={currentSheet?.id || null}
    selectedMeasurementId={selectedMeasurementId}
    onOpenMeasurement={measurement=>{
      const sheet=initialSheets.find((entry:any)=>entry.id===measurement.sheet_id);
      if(sheet&&Number(sheet.page_number)!==pageNumber)changePage(Number(sheet.page_number));
      setSelectedMeasurementId(measurement.id);setTool('select');setInspectorOpen(true);setInspectorTab('properties');
    }}
  />}
  </div>;
}
